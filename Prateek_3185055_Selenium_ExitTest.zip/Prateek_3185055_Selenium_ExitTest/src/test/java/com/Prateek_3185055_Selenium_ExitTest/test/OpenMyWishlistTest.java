package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyOrdersPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyWishlistPage;

//Prateek(3185055)
//OpenMyWishlistTest: It provides all the methods to open my wishlist feature of the website


public class OpenMyWishlistTest extends BaseTest {

	@Test(priority = 18, groups = { "regression","sanity"})
	public void clickOnWishlistOption() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		MyWishlistPage wishlist = new MyWishlistPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		wishlist.clickWishlist();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/wishlist?link=home_wishlist");

	}

//	@Test(priority = 19, groups = { "sanity" })
//	public void SelectProductFromWishlist() throws InterruptedException {
//
//		MyProfilePage myprofile = new MyProfilePage(driver);
//		LoginPage validLogin = new LoginPage(driver);
//		MyWishlistPage wishlist = new MyWishlistPage(driver);
//
//		validLogin.enterEmail("prateek.sen.sd@mmumullana.org");
//		validLogin.enterPassword("Aspirine@flip");
//		validLogin.clickLoginButton();
//		myprofile.hoverProfile();
//		wishlist.clickWishlist();
//		wishlist.clickWishlistItem();
//		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/wishlist?link=home_wishlist");
//	}

}
