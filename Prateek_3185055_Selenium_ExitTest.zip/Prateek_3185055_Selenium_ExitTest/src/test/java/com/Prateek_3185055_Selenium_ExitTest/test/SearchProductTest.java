package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.Prateek_3185055_Selenium_ExitTest.pages.SearchProductPage;


//Prateek(3185055)
//SearchTest: It provides all the methods to test the search functionality


public class SearchProductTest extends BaseTest {

	@Test(priority = 19, groups = { "regression","sanity"})
	public void validSearch() throws Exception {

		SearchProductPage validSearch = new SearchProductPage(driver);

		validSearch.clickOnClose();
		validSearch.enterValidSearch();
		validSearch.clickSearchBox();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions.presenceOfElementLocated(
				By.xpath("//div[normalize-space()='OnePlus Nord CE 2 Lite 5G (Black Dusk, 128 GB)']")));
		Assert.assertEquals(driver.getCurrentUrl(),
				"https://www.flipkart.com/search?q=oneplus%20mobile&otracker=search&otracker1=search&marketplace=FLIPKART&as-show=off&as=off");

	}

	@Test(priority = 20, groups = { "regression","invalid"})
	public void invalidSearch() throws Exception {
		SearchProductPage invalidSearch = new SearchProductPage(driver);

		invalidSearch.clickOnClose();
		invalidSearch.enterInvalidSearch();
		invalidSearch.clickSearchBox();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2))
				.until(ExpectedConditions.presenceOfElementLocated(By.className("_3uTeW4")));
		Assert.assertEquals(driver.getTitle(),
				"E58h24hgfdnlbiu- Buy Products Online at Best Price in India - All Categories | Flipkart.com");

	}

}
