package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.AddressPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;

//Prateek(3185055)
//GiftCardsTest: It provides all the methods to test the gift cards feature of the website



public class GiftCardsTest extends BaseTest {

	@Test(priority = 11, groups = { "regression","sanity"})
	public void clickOnGiftCards() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickGiftCards();
		Assert.assertEquals(driver.getTitle(), "Flipkart Gift Cards: Buy Gift Cards & Gift Vouchers Online | Great Offers & Top Brands | Flipkart");

	}

}
