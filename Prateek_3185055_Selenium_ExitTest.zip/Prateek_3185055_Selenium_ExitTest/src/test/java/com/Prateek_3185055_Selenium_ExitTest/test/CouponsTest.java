package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.AddressPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;


//Prateek(3185055)
//CouponsTest: It provides all the methods to test the coupons feature of the website


public class CouponsTest extends BaseTest {

	@Test(priority = 9, groups = { "regression","sanity"})
	public void clickOnCoupons() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
	

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickCoupons();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/account/rewards?link=home_rewards");

	}

}
