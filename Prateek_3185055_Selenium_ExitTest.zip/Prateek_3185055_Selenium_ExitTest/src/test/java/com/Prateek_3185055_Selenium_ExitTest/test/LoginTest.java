package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;


//Prateek(3185055)
//LoginTest: It provides all the methods to test the login functionality of the website


public class LoginTest extends BaseTest {

	@Test(priority = 12, groups = { "regression","sanity"})
	public void validLogin() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//input[@placeholder='Search for products, brands and more']")));
		Assert.assertEquals(driver.getTitle(),
				"Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");

	}

	@Test(priority = 13, groups = { "regression","invalid"})
	public void invalidLogin() throws Exception {
		LoginPage invalidLogin = new LoginPage(driver);
		invalidLogin.enterInvalidEmail();
		invalidLogin.enterInvalidPassword();
		invalidLogin.clickLoginButton();
		Assert.assertEquals(driver.getTitle(),
				"Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");

	}

	@Test(priority = 14, groups = { "regression","invalid"})
	public void blankLogin() throws Exception {

		LoginPage blankLogin = new LoginPage(driver);
		blankLogin.enterBlankEmail();
		blankLogin.enterBlankPassword();
		blankLogin.clickLoginButton();
		Assert.assertEquals(driver.getTitle(),
				"Online Shopping Site for Mobiles, Electronics, Furniture, Grocery, Lifestyle, Books & More. Best Offers!");

	}

}
