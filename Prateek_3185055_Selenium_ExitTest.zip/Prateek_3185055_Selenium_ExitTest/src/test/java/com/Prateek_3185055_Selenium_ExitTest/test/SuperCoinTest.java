package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyOrdersPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;


//Prateek(3185055)
//SuperCoinTest: It provides all the methods to test the super coin feature of the website



public class SuperCoinTest extends BaseTest {

	@Test(priority = 21, groups = { "regression","sanity"})
	public void clickOnSuperCoinZone() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		MyOrdersPage myorders = new MyOrdersPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickSuperCoin();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/supercoin");

	}

}
