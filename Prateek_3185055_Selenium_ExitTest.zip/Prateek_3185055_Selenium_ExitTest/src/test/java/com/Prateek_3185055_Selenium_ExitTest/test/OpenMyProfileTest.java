package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;


//Prateek(3185055)
//OpenMyProfileTest: It provides all the methods to open my profile feature of the website



public class OpenMyProfileTest extends BaseTest {

	@Test(priority = 17, groups = { "regression","sanity"})
	public void clickOnMyProfile() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickMyProfile();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/account/?rd=0&link=home_account");

	}

}
