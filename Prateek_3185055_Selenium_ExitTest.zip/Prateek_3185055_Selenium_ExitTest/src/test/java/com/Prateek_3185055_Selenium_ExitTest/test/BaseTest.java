package com.Prateek_3185055_Selenium_ExitTest.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.Configurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import com.Prateek_3185055_Selenium_ExitTest.utils.Screenshot;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

//Prateek(3185055)
//BaseTest: It provides all the methods to be executed before and after @Test

public class BaseTest {

	static WebDriver driver;
	public static File file;
	public static FileInputStream fis;
	public static Properties prop;
	public static ExtentReports extent;
	public static ExtentTest extentTest;

	static {
		file = new File("./Resources/config.properties");

		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		prop = new Properties();
		try {
			prop.load(fis);
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	static {
		String log4jConfigFile = System.getProperty("user.dir") + File.separator + "./log4j2.xml";

		Configurator.initialize(null, log4jConfigFile);
	}

	public static Logger log = LogManager.getLogger(BaseTest.class);

	@BeforeSuite(groups = { "regression","sanity","invalid"})
	public void setExtent() {
		extent = new ExtentReports("./Reports/ExtentReport.html");
	}

	@BeforeMethod(groups = { "regression","sanity","invalid"})
	public static void initializeWebdriver() {

		if (prop.getProperty("mode").contains("non-headless"))
			if (prop.getProperty("browser").contains("chrome")) {
				System.setProperty(prop.getProperty("chromedriverProperty"), prop.getProperty("chromedriverPath"));
				driver = new ChromeDriver();
			} else if (prop.getProperty("browser").contains("IE")) {
				System.setProperty(prop.getProperty("edgedriverProperty"), prop.getProperty("edgedriverPath"));
				driver = new EdgeDriver();
			} else if (prop.getProperty("browser").contains("FF")) {
				System.setProperty(prop.getProperty("geckodriverProperty"), prop.getProperty("geckodriverPath"));
				driver = new FirefoxDriver();
			} else {
				System.out.println("Browser is not set");
			}
		else if (prop.getProperty("mode").contains("headless")) {
			if (prop.getProperty("browser").contains("chrome")) {
				System.setProperty(prop.getProperty("chromedriverProperty"), prop.getProperty("chromedriverPath"));
				ChromeOptions options = new ChromeOptions();
				options.setHeadless(true);
				driver = new ChromeDriver(options);
			} else if (prop.getProperty("browser").contains("IE")) {
				System.setProperty(prop.getProperty("edgedriverProperty"), prop.getProperty("edgedriverPath"));
				EdgeOptions edgeOptions = new EdgeOptions();
				//edgeOptions.addArgument("headless");
				driver = new EdgeDriver(edgeOptions);
				//driver = new EdgeDriver();
			} else if (prop.getProperty("browser").contains("FF")) {
				System.setProperty(prop.getProperty("geckodriverProperty"), prop.getProperty("geckodriverPath"));
				FirefoxOptions options = new FirefoxOptions();
				options.setHeadless(true);
				driver = new FirefoxDriver(options);
			} else {
				System.out.println("Browser is not set");
			}
		}

		else {
			System.out.println("Mode is not set");
		}
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);

	}

	@BeforeMethod(groups = { "regression","sanity","invalid"})
	public static void openurl() {
		driver.get(prop.getProperty("url"));
		driver.manage().window().maximize();
	}

	@BeforeMethod(groups = { "regression","sanity","invalid"})
	public void startTest(Method name) {
		String testname = name.getName();
		BaseTest.log.info("In " + testname + " currently");
		extentTest = extent.startTest(testname, "Testing " + testname + " scenario");

	}

	@AfterMethod(groups = { "regression","sanity","invalid"})
	public void testCaseOutput(ITestResult result) throws IOException {

		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshotPath = Screenshot.captureScreenShot(driver, result.getName());
			extentTest.log(LogStatus.FAIL, extentTest.addScreenCapture(screenshotPath));
		} else {
			if (result.getStatus() == ITestResult.SUCCESS) {
				extentTest.log(LogStatus.PASS, "Test case passed successfully");
			}
		}
		extent.endTest(extentTest);
		driver.close();
		//driver.quit();

	}

	@AfterSuite(groups = { "regression","sanity","invalid"})
	public void endReport() {
		extent.flush();
		extent.close();
	}

}
