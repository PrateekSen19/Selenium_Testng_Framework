package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.CategoriesPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.LogoutPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyOrdersPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;



//Prateek(3185055)
//CategoriesTest: It provides all the methods to test the categories feature of the website


public class CategoriesTest extends BaseTest {

	@Test(priority = 4, groups = { "regression","sanity"})
	public void clickOnTopOffersCategory() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		CategoriesPage topoffer = new CategoriesPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		topoffer.clickTopOffers();
		topoffer.clickViewAllTopOffers();
		WebElement myDynamicElement = (new WebDriverWait(driver, 4))
				.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@class='_1Yt2GF']")));
		Assert.assertEquals(driver.getCurrentUrl(),
				"https://www.flipkart.com/offers-list/top-offers?screen=dynamic&pk=themeViews%3DBSDBookOffers%3ABSDBookOffersdesk~widgetType%3DdealCard~contentType%3Dneo&wid=12.dealCard.OMU_3&otracker=clp_omu_Top%2BOffers_offers-store_3&otracker1=clp_omu_PINNED_neo%2Fmerchandising_Top%2BOffers_NA_wc_view-all_3");

	}

	@Test(priority = 5, groups = { "regression","sanity"})
	public void clickOnGroceryCategory() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		CategoriesPage topoffer = new CategoriesPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		topoffer.clickGrocery();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//h2[normalize-space()='Shop By Top Categories']")));
		Assert.assertEquals(driver.getTitle(),
				"Flipkart Grocery Store - Buy Groceries Online & Get Rs.1 Deals at Flipkart.com");

	}

	@Test(priority = 6, groups = { "regression","sanity"})
	public void clickOnMobilesCategory() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		CategoriesPage topoffer = new CategoriesPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		topoffer.clickMobiles();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//h1[@class='_3vKRL2']")));
		Assert.assertEquals(driver.getTitle(),
				"Mobile Phones Online at Best Prices in India");

	}
	
	
	@Test(priority = 7, groups = { "regression","sanity"})
	public void clickOnAppliancesCategory() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		CategoriesPage topoffer = new CategoriesPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		topoffer.clickAppliances();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//h1[@class='_3vKRL2']")));
		Assert.assertEquals(driver.getTitle(),
				"Tvs And Appliances New Clp Store Online - Buy Tvs And Appliances New Clp Online at Best Price in India | Flipkart.com");

	}
	
	
	@Test(priority = 8, groups = { "regression","sanity"})
	public void clickOnTravelCategory() throws Exception {

		LoginPage validLogin = new LoginPage(driver);
		CategoriesPage topoffer = new CategoriesPage(driver);

		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		topoffer.clickTravel();
		WebElement myDynamicElement = (new WebDriverWait(driver, 2)).until(ExpectedConditions
				.presenceOfElementLocated(By.xpath("//div[@class='aCgX3e']//img[@class='kJjFO0 _3DIhEh']")));
		Assert.assertEquals(driver.getTitle(),
				"Flight Booking | Book Flight Tickets at Lowest Airfare on Flipkart.com");

	}

}
