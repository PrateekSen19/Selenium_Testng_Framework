package com.Prateek_3185055_Selenium_ExitTest.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.Prateek_3185055_Selenium_ExitTest.pages.AddressPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.LoginPage;
import com.Prateek_3185055_Selenium_ExitTest.pages.MyProfilePage;


//Prateek(3185055)
//AddressTest: It provides all the methods to test the functionality of address of the website


public class AddressTest extends BaseTest {

	@Test(priority = 1, groups = { "regression","sanity"})
	public void addNewAddress() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		AddressPage address = new AddressPage(driver);
		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickMyProfile();
		address.hoverFlights();
		address.clickManageAddresses();
		address.clickAddNewAddress();
		address.enterName();
		address.enterPhone();
		address.enterPincode();
		address.enterLocality();
		address.enterAddress();
		address.clickHome();
		address.clickSave();
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/account/addresses");

	}

	@Test(priority = 2, groups = { "regression","sanity" })
	public void editNewAddress() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		AddressPage address = new AddressPage(driver);
		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickMyProfile();
		address.hoverFlights();
		address.clickManageAddresses();
		address.hoverAddressOptions();
		address.clickEdit();
		address.enterLandmark();
		address.enterAternateNumber();
		address.clickSave();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/account/addresses");

	}

	@Test(priority = 3, groups = { "regression","sanity"})
	public void deleteNewAddress() throws Exception {

		MyProfilePage myprofile = new MyProfilePage(driver);
		LoginPage validLogin = new LoginPage(driver);
		AddressPage address = new AddressPage(driver);
		validLogin.enterEmail();
		validLogin.enterPassword();
		validLogin.clickLoginButton();
		myprofile.hoverProfile();
		myprofile.clickMyProfile();
		address.hoverFlights();
		address.clickManageAddresses();
		address.hoverAddressOptions();
		address.clickDelete();
		Thread.sleep(1000);
		address.clickConfirmDelete();
		Thread.sleep(2000);
		Assert.assertEquals(driver.getCurrentUrl(), "https://www.flipkart.com/account/addresses");

	}

}
