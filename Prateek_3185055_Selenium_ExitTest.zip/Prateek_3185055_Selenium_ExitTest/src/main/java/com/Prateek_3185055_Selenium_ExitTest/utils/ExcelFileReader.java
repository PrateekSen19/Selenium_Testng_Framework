package com.Prateek_3185055_Selenium_ExitTest.utils;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


//Prateek(3185055)
//ExcelFileReader:  This class contains methods to read data from excel file 

public class ExcelFileReader {

	public static void getRowsCount() throws Exception {

		String excelPath = "./Excel/Excel.xlsx";
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		int rowCount = sheet.getPhysicalNumberOfRows();
		System.out.println("No. of Rows " + rowCount);

	}

	public String getCellData(int row_num, int cell_num) throws Exception {
		File file = new File("./Excel/Excel.xlsx");
		FileInputStream inputStream = new FileInputStream(file);

		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = workbook.getSheet("Sheet1");

		String value = sheet.getRow(row_num).getCell(cell_num).getStringCellValue();
		//
		return value;
	}

}
