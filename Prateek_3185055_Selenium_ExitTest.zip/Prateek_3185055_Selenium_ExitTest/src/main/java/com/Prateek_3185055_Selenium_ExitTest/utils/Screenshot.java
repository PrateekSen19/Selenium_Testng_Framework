package com.Prateek_3185055_Selenium_ExitTest.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;


//Prateek(3185055)
//ExcelFileReader:  This class contains methods to take the screenshot of failed test case
public class Screenshot {

	public static String captureScreenShot(WebDriver driver, String testName) throws IOException {

		String imagepath = System.getProperty("user.dir") + "/FailedScreenshots/" + testName + ".jpg";

		File srcfile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(srcfile, new File(imagepath));

		return imagepath;
	}

}
