package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//Prateek(3185055)
//MyProfilePage: Define all web Elements through PageFactory Method

public class MyProfilePage {

	WebDriver driver;

	public MyProfilePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//div[text()='Prateek']")
	public WebElement prateek;

	@FindBy(how = How.LINK_TEXT, using = "My Profile")
	public WebElement myprofile;
	
	@FindBy(how = How.LINK_TEXT, using = "SuperCoin Zone")
	public WebElement supercoin;
	
	@FindBy(how = How.LINK_TEXT, using = "Flipkart Plus Zone")
	public WebElement flipkartPlus;
	
	@FindBy(how = How.LINK_TEXT, using = "Coupons")
	public WebElement coupons;
	
	@FindBy(how = How.LINK_TEXT, using = "Gift Cards")
	public WebElement giftcards;
	
	@FindBy(how = How.LINK_TEXT, using = "Notifications")
	public WebElement notifications;

	public void hoverProfile() throws InterruptedException {
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.moveToElement(prateek).perform();
	}

	public void clickMyProfile() throws InterruptedException {
		myprofile.click();
		Thread.sleep(4000);
	}
	
	public void clickSuperCoin() throws InterruptedException {
		supercoin.click();
		Thread.sleep(4000);
	}
	
	public void clickFlipkartPlus() throws InterruptedException {
		flipkartPlus.click();
		Thread.sleep(4000);
	}
	
	public void clickCoupons() throws InterruptedException {
		coupons.click();
		Thread.sleep(4000);
	}
	
	public void clickGiftCards() throws InterruptedException {
		giftcards.click();
		Thread.sleep(4000);
	}
	
	public void clickNotifications() throws InterruptedException {
		notifications.click();
		Thread.sleep(4000);
	}

}
