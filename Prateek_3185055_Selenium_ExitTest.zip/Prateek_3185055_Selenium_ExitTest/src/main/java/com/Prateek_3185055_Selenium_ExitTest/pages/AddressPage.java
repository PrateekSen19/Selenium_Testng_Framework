package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.Prateek_3185055_Selenium_ExitTest.utils.ExcelFileReader;

//Prateek(3185055)
//AddressPage: Define all web Elements through PageFactory Method

public class AddressPage {

	WebDriver driver;

	public AddressPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.LINK_TEXT, using = "Flights")
	public WebElement hover;

	@FindBy(how = How.XPATH, using = "//div[normalize-space()='Manage Addresses']")
	public WebElement manageAddresses;

	@FindBy(how = How.XPATH, using = "//div[@class='_1QhEVk']")
	public WebElement addNewAddress;

	@FindBy(how = How.XPATH, using = "//input[@name='name']")
	public WebElement addName;

	@FindBy(how = How.XPATH, using = "//input[@name='phone']")
	public WebElement addPhone;

	@FindBy(how = How.XPATH, using = "//input[@name='pincode']")
	public WebElement addPincode;

	@FindBy(how = How.XPATH, using = "//input[@name='addressLine2']")
	public WebElement addLocality;

	@FindBy(how = How.XPATH, using = "//textarea[@name='addressLine1']")
	public WebElement addAddress;

	@FindBy(how = How.XPATH, using = "//label[@for='HOME']//div[@class='_1XFPmK']")
	public WebElement addHome;

	@FindBy(how = How.XPATH, using = "//button[normalize-space()='Save']")
	public WebElement save;

	@FindBy(how = How.XPATH, using = "//body/div[@id='container']/div/div[@class='_1TzjCl']/div[@class='nt9Nxn row']/div[@class='w0WEfC']/div[@class='_2n7_Qo']/div[@class='_3E8aIl _3F7kj3']/div/div/div[1]/div[1]/div[1]/div[1]")
	public WebElement options;

	@FindBy(how = How.XPATH, using = "//div[@class='_3E8aIl _3F7kj3']//div//div[1]//div[1]//div[1]//div[1]//div[1]//div[1]")
	public WebElement edit;
	
	@FindBy(how = How.XPATH, using = "//div[@class='_3E8aIl _3F7kj3']//div//div[1]//div[1]//div[1]//div[1]//div[1]//div[2]")
	public WebElement delete;
	
	@FindBy(how = How.XPATH, using = "//button[@class='_2KpZ6l ZRrG8H _3AWRsL']")
	public WebElement confirmDelete;
	
	@FindBy(how = How.XPATH, using = "//input[@name='landmark']")
	public WebElement addLandmark;
	
	@FindBy(how = How.XPATH, using = "//input[@name='alternatePhone']")
	public WebElement addAlternatePhone;	
	
	public void hoverFlights() throws InterruptedException {
		Thread.sleep(4000);
		Actions action = new Actions(driver);
		action.moveToElement(hover).perform();
		Thread.sleep(2000);
	}

	public void clickManageAddresses() throws InterruptedException {
		manageAddresses.click();
		Thread.sleep(4000);
	}

	public void clickAddNewAddress() throws InterruptedException {
		addNewAddress.click();
		Thread.sleep(4000);
	}

	public void enterName() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String name = reader.getCellData(6, 1);
		addName.sendKeys(name);

	}

	public void enterPhone() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String number = reader.getCellData(7, 1);
		addPhone.sendKeys(number);

	}

	public void enterPincode() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String pincode = reader.getCellData(8, 1);
		addPincode.sendKeys(pincode);

	}

	public void enterLocality() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String locality = reader.getCellData(9, 1);
		addLocality.sendKeys(locality);

	}

	public void enterAddress() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String address = reader.getCellData(10, 1);
		addAddress.sendKeys(address);
		Thread.sleep(1000);
	}

	public void clickHome() throws InterruptedException {
		addHome.click();
	}

	public void clickSave() throws InterruptedException {
		save.click();
		Thread.sleep(1000);
	}

	public void hoverAddressOptions() throws InterruptedException {
		Thread.sleep(2000);
		Actions action = new Actions(driver);
		action.moveToElement(options).perform();
		Thread.sleep(1000);
	}

	public void clickEdit() throws InterruptedException {
		edit.click();
		Thread.sleep(1000);
	}
	
	public void clickDelete() throws InterruptedException {
		delete.click();
		Thread.sleep(1000);
	}
	
	public void clickConfirmDelete() throws InterruptedException {
		confirmDelete.click();
		Thread.sleep(1000);
	}
	
	public void enterLandmark() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String landmark = reader.getCellData(11, 1);
		addLandmark.sendKeys(landmark);
		Thread.sleep(1000);
	}
	
	public void enterAternateNumber() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String alternatenumber = reader.getCellData(12, 1);
		addAlternatePhone.sendKeys(alternatenumber);
		Thread.sleep(1000);
	}

}
