package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.Prateek_3185055_Selenium_ExitTest.utils.ExcelFileReader;


//Prateek(3185055)
//SearchProductPage: Locators to test Search Functionality

public class SearchProductPage {
	
	WebDriver driver;

	public SearchProductPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}
	
	@FindBy(how = How.XPATH, using = "//button[@class='_2KpZ6l _2doB4z']")
	public WebElement close;

	@FindBy(how = How.XPATH, using = "//input[@placeholder='Search for products, brands and more']")
	public WebElement searchBox;

	@FindBy(how = How.CLASS_NAME, using = "L0Z3Pu")
	public WebElement searchButton;


	
	public void clickOnClose() {
		close.click();
	}
	
	
	public void enterValidSearch() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String validSearch = reader.getCellData(4, 1);
		searchBox.sendKeys(validSearch);
	}
	
	public void enterInvalidSearch() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String invalidSearch = reader.getCellData(5, 1);
		searchBox.sendKeys(invalidSearch);
	}

	public void clickSearchBox() {
		searchButton.click();
	}

	

}
