package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//Prateek(3185055)
//MyOrdersPage: Define all web Elements through PageFactory Method

public class MyOrdersPage {

	WebDriver driver;

	public MyOrdersPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.LINK_TEXT, using = "Orders")
	public WebElement myorders;

	public void clickOrders() throws InterruptedException {
		myorders.click();
		Thread.sleep(4000);
	}

}
