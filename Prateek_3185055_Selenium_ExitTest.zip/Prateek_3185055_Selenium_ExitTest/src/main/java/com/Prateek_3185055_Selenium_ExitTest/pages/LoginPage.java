package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.Prateek_3185055_Selenium_ExitTest.utils.ExcelFileReader;

//Prateek(3185055)
//LoginPage: Define all web Elements through PageFactory Method

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//input[@class='_2IX_2- VJZDxU']")
	public WebElement userEmail;

	@FindBy(how = How.XPATH, using = "//input[@type='password']")
	public WebElement userPassword;

	@FindBy(how = How.XPATH, using = "//button[@class='_2KpZ6l _2HKlqd _3AWRsL']")
	public WebElement loginButton;

	public void enterEmail() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String email = reader.getCellData(0, 1);
		userEmail.sendKeys(email);
	}

	public void enterPassword() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String pass = reader.getCellData(1, 1);
		userPassword.sendKeys(pass);
	}

	public void enterInvalidEmail() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String email = reader.getCellData(2, 1);
		userEmail.sendKeys(email);
	}

	public void enterInvalidPassword() throws Exception {
		ExcelFileReader reader = new ExcelFileReader();
		String pass = reader.getCellData(3, 1);
		userPassword.sendKeys(pass);
	}

	public void enterBlankEmail() throws Exception {
		userEmail.sendKeys("");

	}

	public void enterBlankPassword() throws Exception {
		userPassword.sendKeys("");

	}

	public void clickLoginButton() {
		loginButton.click();

	}

}
