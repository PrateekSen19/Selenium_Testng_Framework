package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//Prateek(3185055)
//CategoriesPage: Define all web Elements through PageFactory Method

public class CategoriesPage {

	WebDriver driver;

	public CategoriesPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Top Offers')]")
	public WebElement topOffers;

	@FindBy(how = How.XPATH, using = "//body/div[@id='container']/div[1]/div[3]/div[4]/div[1]/div[1]/div[1]/div[1]/a[1]")
	public WebElement viewAllTopOffers;

	@FindBy(how = How.LINK_TEXT, using = "Grocery")
	public WebElement grocery;

	@FindBy(how = How.LINK_TEXT, using = "Appliances")
	public WebElement appliances;

	@FindBy(how = How.LINK_TEXT, using = "Travel")
	public WebElement travel;

	@FindBy(how = How.LINK_TEXT, using = "Mobiles")
	public WebElement mobiles;

	public void clickTopOffers() throws InterruptedException {
		Thread.sleep(4000);
		topOffers.click();

	}

	public void clickViewAllTopOffers() throws InterruptedException {
		viewAllTopOffers.click();
	}

	public void clickGrocery() throws InterruptedException {
		Thread.sleep(2000);
		grocery.click();
	}

	public void clickMobiles() throws InterruptedException {
		Thread.sleep(2000);
		mobiles.click();
	}

	public void clickAppliances() throws InterruptedException {
		Thread.sleep(2000);
		appliances.click();
	}

	public void clickTravel() throws InterruptedException {
		Thread.sleep(2000);
		travel.click();
	}

}
