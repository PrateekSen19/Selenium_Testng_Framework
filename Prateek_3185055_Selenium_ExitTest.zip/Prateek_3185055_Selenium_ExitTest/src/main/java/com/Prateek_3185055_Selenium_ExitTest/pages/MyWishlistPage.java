package com.Prateek_3185055_Selenium_ExitTest.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//Prateek(3185055)
//MyWishlistPage: Define all web Elements through PageFactory Method

public class MyWishlistPage {

	WebDriver driver;

	public MyWishlistPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
	}

	@FindBy(how = How.XPATH, using = "//a[@href='/wishlist?link=home_wishlist']")
	public WebElement mywishlist;

	@FindBy(how = How.XPATH, using = "//div[normalize-space()='Aquire Bedroom Romantic Rose Flowers Extra Large Self Adhesive Sticker']")
	public WebElement wishlistitem;

	public void clickWishlist() throws InterruptedException {
		mywishlist.click();
		Thread.sleep(4000);
	}
	
	public void clickWishlistItem() throws InterruptedException {
		wishlistitem.click();
		Thread.sleep(4000);
	}

}
